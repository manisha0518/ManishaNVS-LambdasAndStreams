# Manisha-Java-8-Lambdas-and-Streams
EPAM task on java 8 - Lambdas and Streams - Manisha NVS
